// function showOptions() {
//     var frequency = document.getElementById("frequency").value;
//     if (frequency === "weekly") {
//         document.getElementById("weekly_options").style.display = "block";
//         //document.getElementById("bi_weekly_options").style.display = "none";
//         document.getElementById("monthly_options").style.display = "none";
//     } else if (frequency === "monthly") {
//         document.getElementById("weekly_options").style.display = "none";
//         //document.getElementById("bi_weekly_options").style.display = "none";
//         document.getElementById("monthly_options").style.display = "block";
//     } else {
//         document.getElementById("weekly_options").style.display = "none";
//         //document.getElementById("bi_weekly_options").style.display = "none";
//         document.getElementById("monthly_options").style.display = "none";
//     }
//     // } else if (frequency === "custom") {
//     //     document.getElementById("frequencyHelp").innerHTML = "you'll get to set the frequency later";
//     // }
// }